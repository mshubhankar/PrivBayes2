#!/bin/bash
./privbayes_new adult 1 1 4;


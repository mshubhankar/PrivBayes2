import pandas as pd

df = pd.read_csv(r"adult-short.dat", header=None, sep=',')

df.to_csv('adult-short.dat', header=False, index=False, sep=' ')